# -*- coding: utf-8 -*-
{
  "name" : "Add fields event",
  "version" : "0.1",
  "author" : "DEVTALENTS",
  'summary': 'Add fields in event',
  'website': 'https://www.dev-talents.com/',
  'description': """
    Add fields in event
  """,

  "depends" : [
         "event",
         "website_event",
               ],
  'data': [

          'views/add_fields.xml',

          ],

  "installable": True,

}





