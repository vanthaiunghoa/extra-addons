# -*- coding: utf-8 -*-
{
  "name" : "Add fields Blog",
  "version" : "0.1",
  "author" : "Devtalents",
  "category" : "Website",
  "summary": "News, Blogs, Announces, Discussions",
  'website': 'http://www.dev-talents.com/',
  'description': """
  """,
  "depends" : ["website_blog"],
  'data': ['view/add.xml'],

  "installable": True, 
}





